document.querySelector('form')?.addEventListener('submit',event=>{
  event.preventDefault();
  document.querySelector('#form-status').textContent='Validación local correcta. No se envió ningún mensaje: esta es una maqueta sin conexión a WordPress.com.';
});
