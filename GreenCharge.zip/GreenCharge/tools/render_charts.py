#!/usr/bin/env python3
"""Reference plots only. These are not Flourish visualisations."""
import os
os.environ.setdefault('MPLCONFIGDIR','/tmp/greencharge-matplotlib')
import csv
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter

root=Path(__file__).resolve().parents[1]
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':11,'axes.spines.top':False,'axes.spines.right':False,'axes.spines.left':False,'axes.spines.bottom':False,'svg.fonttype':'none','text.color':'#12312A','axes.labelcolor':'#12312A','xtick.color':'#53685c','ytick.color':'#53685c'})
with (root/'datos/piloto-mensual.csv').open(encoding='utf-8-sig') as f: rows=list(csv.DictReader(f))
fig,ax=plt.subplots(figsize=(10,4.7),layout='constrained')
values=[int(r['Sesiones']) for r in rows]
ax.plot([r['Mes'] for r in rows],values,color='#176b4d',linewidth=3,marker='o',markersize=7)
ax.fill_between(range(6),values,alpha=.09,color='#176b4d')
for i,v in enumerate(values):ax.annotate(str(v),(i,v),xytext=(0,12),textcoords='offset points',ha='center',color='#12312a',weight='bold')
ax.set_ylim(0,450);ax.set_ylabel('Sesiones de carga');ax.grid(axis='y',color='#e5ece1');ax.set_axisbelow(True)
ax.set_title('Uso de carga en el piloto académico',loc='left',fontsize=17,pad=25)
fig.savefig(root/'datos/lineas.svg');plt.close(fig)
with (root/'datos/comparacion-costos.csv').open(encoding='utf-8-sig') as f: rows=list(csv.DictReader(f))
fig,ax=plt.subplots(figsize=(10,4.7),layout='constrained')
values=[int(r['Costo mensual (CLP)']) for r in rows]
bars=ax.barh([r['Escenario'] for r in rows],values,color=['#176b4d','#3c8966','#94bc76','#67766e'],height=.57)
ax.invert_yaxis();ax.set_xlim(0,110000);ax.set_xlabel('Costo energético mensual simulado (CLP)')
ax.xaxis.set_major_formatter(FuncFormatter(lambda x,_:format(int(x),',').replace(',','.')))
for b,v in zip(bars,values):ax.text(v+2000,b.get_y()+b.get_height()/2,'$'+format(v,',').replace(',','.'),va='center',fontsize=11,weight='bold')
ax.grid(axis='x',color='#e5ece1');ax.set_axisbelow(True)
ax.set_title('Cuatro escenarios para 1.000 km al mes',loc='left',fontsize=17,pad=25)
fig.savefig(root/'datos/barras.svg');plt.close(fig)
print('Bocetos SVG generados. No se crearon visualizaciones en Flourish.')
