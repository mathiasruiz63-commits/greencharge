#!/usr/bin/env python3
"""Build review files and WordPress WXR; never connects to or publishes a site."""
import argparse
import csv
import html
import json
import re
from pathlib import Path
from urllib.parse import urlparse
from xml.etree import ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
DATA = json.loads((ROOT / 'contenido.json').read_text())
CONFIG = json.loads((ROOT / 'wordpress/config.public.json').read_text())
ARGS = argparse.ArgumentParser()
ARGS.add_argument('--publish', action='store_true', help='Generate publish-status XML only after public URLs are supplied; does not publish anything.')
OPT = ARGS.parse_args()
E = html.escape
ARTICLE = DATA['article']
SLUG = ARTICLE['slug']
ASSETS = {'hogar': 'Carga residencial conceptual.', 'estacion': 'Estación de carga conceptual en Santiago.', 'equipo': 'Inspección conceptual de un cargador cerrado.'}
IMAGES = ['hogar', 'hogar', 'estacion', 'equipo', 'estacion', 'equipo']
URL = CONFIG['site_url'].rstrip('/')

def valid_https(value):
    u = urlparse(value)
    return u.scheme == 'https' and bool(u.hostname) and not u.username and not u.password

def valid_flourish(value):
    u = urlparse(value)
    return valid_https(value) and u.hostname == 'public.flourish.studio' and bool(re.fullmatch(r'/visualisation/\d+/?', u.path))

if OPT.publish:
    chart_urls=[CONFIG['flourish'].get(k,'').rstrip('/') for k in ['sesiones','costos']]
    if not valid_https(URL) or not all(valid_https(CONFIG['media'].get(k, '')) for k in ASSETS) or not all(valid_flourish(u) for u in chart_urls) or len(set(chart_urls))!=2:
        raise SystemExit('Faltan URL HTTPS públicas del sitio, las tres imágenes o las dos visualizaciones reales de Flourish. No se generó XML con estado público.')

def block(kind, markup='', attrs=None):
    attr = ' ' + json.dumps(attrs, ensure_ascii=False, separators=(',', ':')) if attrs else ''
    if markup is None:
        return f'<!-- wp:{kind}{attr} /-->\n'
    return f'<!-- wp:{kind}{attr} -->\n{markup}\n<!-- /wp:{kind} -->\n'

def p(text): return block('paragraph', '<p>' + E(text) + '</p>')
def h(text, level=2): return block('heading', f'<h{level} class="wp-block-heading">{E(text)}</h{level}>', {'level': level})
def link(path): return URL + path if URL else path
def button(label, path):
    return block('buttons', '<div class="wp-block-buttons">' + block('button', f'<div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="{E(link(path),quote=True)}">{E(label)}</a></div>') + '</div>')
def image(name, preview=False, caption=None):
    caption = caption or 'Imagen conceptual generada con IA para Green Charge; no corresponde a una instalación real.'
    src = '../assets/' + name + '.png' if preview else CONFIG['media'].get(name)
    if not src:
        return p(f'[IMAGEN PENDIENTE: subir assets/{name}.png e insertar aquí. Texto alternativo: {ASSETS[name]}]')
    markup = f'<figure class="wp-block-image size-large"><img src="{E(src,quote=True)}" alt="{E(ASSETS[name],quote=True)}"/><figcaption class="wp-element-caption">{E(caption)}</figcaption></figure>'
    return markup if preview else block('image', markup, {'sizeSlug': 'large', 'linkDestination': 'none'})

def columns(contents):
    inner = ''.join(block('column', '<div class="wp-block-column">' + s + '</div>') for s in contents)
    return block('columns', '<div class="wp-block-columns">' + inner + '</div>')

def table(filename, cols):
    with (ROOT / 'datos' / filename).open(encoding='utf-8-sig') as f: rows = list(csv.reader(f))
    tr = lambda cells,tag: '<tr>' + ''.join('<'+tag+'>'+E(c)+'</'+tag+'>' for c in cells[:cols]) + '</tr>'
    markup = '<figure class="wp-block-table"><table class="has-fixed-layout"><thead>'+tr(rows[0],'th')+'</thead><tbody>'+''.join(tr(r,'td') for r in rows[1:])+'</tbody></table></figure>'
    return block('table', markup, {'hasFixedLayout': True})

def chart(key):
    number = 0 if key == 'sesiones' else 1
    meta = DATA['charts'][number]
    out = h(meta['title']) + p(meta['subtitle'])
    url = CONFIG['flourish'].get(key)
    if url:
        out += block('embed', '<figure class="wp-block-embed is-type-rich"><div class="wp-block-embed__wrapper">\n' + E(url) + '\n</div></figure>', {'url': url, 'type': 'rich', 'responsive': True})
    else:
        out += p('[VISUALIZACIÓN FLOURISH PENDIENTE: ' + ('gráfico de líneas con datos/piloto-mensual.csv' if number == 0 else 'gráfico de barras horizontales con datos/comparacion-costos.csv') + '. No sustituir por una captura o un enlace.]')
    out += table('piloto-mensual.csv' if number == 0 else 'comparacion-costos.csv', 2)
    return out + p(meta['source'])

def home():
    d = DATA['home']
    out = p('GREEN CHARGE · MOVILIDAD ELÉCTRICA') + h(d['title']) + p(d['lead']) + button(d['primary_cta']['label'],d['primary_cta']['url']) + image('estacion')
    out += columns([h(m['title'],3)+p(m['text']) for m in d['modules'][:3]])
    out += h('Explora nuestras soluciones') + p('Carga residencial, empresas y flotas. Conoce las seis propuestas del catálogo.') + button('Ver las seis soluciones','/soluciones/')
    out += h('Últimos artículos')
    out += block('latest-posts', None, {'postsToShow':3, 'displayPostContent':True, 'excerptLength':32, 'displayFeaturedImage':True})
    return out + h('Planifica tu siguiente paso') + p('Cuéntanos qué espacio y qué uso tienes en mente.') + button('Contactar','/contacto/') + p(DATA['project']['academic_notice'])

def company():
    d=DATA['company']
    out=h(d['title'])+image('equipo')+h('Nuestra historia')+''.join(p(t) for t in d['history'])
    out+=columns([h('Misión',3)+p(d['mission']),h('Visión',3)+p(d['vision'])])+h('Nuestro equipo')+p(d['team_notice'])
    out+=columns([h(m['name'],3)+p(m['role'])+p(m['bio']) for m in d['team']])
    return out+button('Conoce nuestras soluciones','/soluciones/')

def catalog():
    d=DATA['catalog']; out=h(d['title'])+p(d['intro'])
    for i in range(0,6,2):
        cards=[]
        for j in [i,i+1]:
            x=d['products'][j]
            cards.append(image(IMAGES[j])+h(x['name'],3)+p(x['description'])+p(x['price_label'])+p(x['observations'])+button('Consultar esta solución','/contacto/'))
        out+=columns(cards)
    return out

def contact():
    out=h('Hablemos de tu proyecto')+p('Escríbenos para conversar sobre la propuesta académica Green Charge. No se reciben compras, reservas ni solicitudes comerciales reales.')
    out+=columns([h('Datos de contacto',3)+p('Green Charge · Proyecto académico ficticio')+p('Ubicación referencial: Santiago, Región Metropolitana, Chile. Sin local comercial ni atención presencial.')+p('Canal de contacto: formulario de este sitio. Las respuestas dependen del administrador del proyecto.'),h('Envíanos un mensaje',3)+block('shortcode','[contact-form subject="Consulta Green Charge"]\n[contact-field label="Nombre" type="name" required="true" /]\n[contact-field label="Correo electrónico" type="email" required="true" /]\n[contact-field label="Mensaje" type="textarea" required="true" /]\n[/contact-form]')])
    out+=h('Ubicación referencial')+p('El mapa muestra Santiago como contexto del proyecto; no identifica una oficina ni un punto de carga real.')
    out+=block('shortcode','[googlemaps https://maps.google.com/maps?q=Santiago,+Chile&z=12&output=embed&w=640&h=400]')
    out+=p('Utiliza el formulario para contactar al administrador del proyecto académico. No incluyas datos sensibles en el mensaje.')
    return out

def article():
    out=p(ARTICLE['notice'])+p(ARTICLE['lead'])+image('estacion')
    for i,s in enumerate(ARTICLE['sections']):
        out+=h(s['heading'])+''.join(p(x) for x in s['paragraphs'])
        if i==0: out+=image('hogar')
        if i==1:
            q=ARTICLE['quote']
            out+=block('quote','<blockquote class="wp-block-quote">'+p(q['text'])+'<cite>'+E(q['attribution']+' '+q['notice'])+'</cite></blockquote>')+chart('sesiones')
        if i==2: out+=chart('costos')+image('equipo')
        if i==3: out+=columns([h(c['heading'],3)+''.join(p(x) for x in c['paragraphs']) for c in ARTICLE['two_columns']])
    out+=h('Metodología y archivos de datos')+p('Fuente: elaboración propia. Todas las cifras son sintéticas. Energía del piloto = sesiones × 18 kWh. Costo mensual = distancia / 100 × consumo por 100 km × precio unitario. No se atribuyen datos ni declaraciones a fuentes reales.')+button('Explora las soluciones','/soluciones/')
    return out

PAGES=[(101,'Inicio','inicio',home()),(102,'Empresa','empresa',company()),(103,'Soluciones','soluciones',catalog()),(104,'Contacto','contacto',contact())]
POST=(201,ARTICLE['title'],SLUG,article())

# WordPress WXR 1.2. Drafts preserve explicitly visible pending assets.
NS={'content':'http://purl.org/rss/1.0/modules/content/','excerpt':'http://wordpress.org/export/1.2/excerpt/','dc':'http://purl.org/dc/elements/1.1/','wp':'http://wordpress.org/export/1.2/'}
for k,v in NS.items(): ET.register_namespace(k,v)
def tag(k):
    if ':' in k:
        n,t=k.split(':',1); return '{'+NS[n]+'}'+t
    return k
def add(parent,k,value): ET.SubElement(parent,tag(k)).text=str(value)
rss=ET.Element('rss',version='2.0'); channel=ET.SubElement(rss,'channel')
for k,v in [('title','Green Charge'),('link',URL or 'https://example.invalid'),('description',DATA['project']['tagline']),('language','es-CL'),('wp:wxr_version','1.2'),('wp:base_site_url',URL or 'https://example.invalid'),('wp:base_blog_url',URL or 'https://example.invalid')]: add(channel,k,v)
author=ET.SubElement(channel,tag('wp:author'))
for k,v in [('author_id',1),('author_login','greencharge'),('author_email',''),('author_display_name','Green Charge')]:add(author,'wp:'+k,v)
cat=ET.SubElement(channel,tag('wp:category'))
for k,v in [('term_id',1),('category_nicename','articulos'),('category_parent',''),('cat_name','Artículos')]:add(cat,'wp:'+k,v)
for row,kind in [(x,'page') for x in PAGES]+[(POST,'post')]:
    id,title,slug,body=row; item=ET.SubElement(channel,'item')
    for k,v in [('title',title),('link',link('/'+slug+'/')),('dc:creator','greencharge'),('guid',link('/?p='+str(id))),('description',''),('content:encoded',body),('excerpt:encoded',ARTICLE['excerpt'] if kind=='post' else ''),('wp:post_id',id),('wp:post_date','2026-10-16 09:00:00'),('wp:post_date_gmt','2026-10-16 12:00:00'),('wp:comment_status','closed'),('wp:ping_status','closed'),('wp:post_name',slug),('wp:status','publish' if OPT.publish else 'draft'),('wp:post_parent',0),('wp:menu_order',0),('wp:post_type',kind),('wp:post_password',''),('wp:is_sticky',0)]:add(item,k,v)
    if kind=='post':ET.SubElement(item,'category',domain='category',nicename='articulos').text='Artículos'
    if kind=='post' and valid_https(CONFIG['media'].get('estacion','')):
        meta=ET.SubElement(item,tag('wp:postmeta'))
        add(meta,'wp:meta_key','_thumbnail_id');add(meta,'wp:meta_value',302)
for aid,n in enumerate(ASSETS,301):
    src=CONFIG['media'].get(n,'')
    if not valid_https(src): continue
    item=ET.SubElement(channel,'item')
    for k,v in [('title','Green Charge · '+n),('link',src),('dc:creator','greencharge'),('guid',src),('content:encoded',''),('wp:post_id',aid),('wp:post_date','2026-10-16 09:00:00'),('wp:post_date_gmt','2026-10-16 12:00:00'),('wp:post_name','greencharge-'+n),('wp:status','inherit'),('wp:post_parent',201),('wp:post_type','attachment'),('wp:post_mime_type','image/png'),('wp:attachment_url',src)]:add(item,k,v)
    meta=ET.SubElement(item,tag('wp:postmeta'))
    add(meta,'wp:meta_key','_wp_attachment_image_alt');add(meta,'wp:meta_value',ASSETS[n])
name='greencharge-publicable.xml' if OPT.publish else 'greencharge-borrador.xml'
ET.indent(rss); ET.ElementTree(rss).write(ROOT/'wordpress'/name,encoding='utf-8',xml_declaration=True)
for _,title,slug,body in PAGES+[POST]: (ROOT/'wordpress'/(slug+'.html')).write_text(body)
nav=''.join(block('navigation-link',None,{'label':x['label'],'url':link(x['slug']),'kind':'custom','isTopLevelLink':True}) for x in DATA['project']['navigation'])
(ROOT/'wordpress/navegacion.html').write_text(block('navigation',nav,{'overlayMenu':'mobile','layout':{'type':'flex','justifyContent':'right'}}))

# Self-contained local design mock-up. It is not a WordPress.com deployment.
def preview_body(body):
    body=re.sub(r'<!--.*?-->','',body,flags=re.S)
    for n in ASSETS:
        body=re.sub(r'<p>\[IMAGEN PENDIENTE: subir assets/'+n+r'\.png.*?</p>',image(n,True),body)
    body=body.replace('[contact-form subject="Consulta Green Charge"]\n[contact-field label="Nombre" type="name" required="true" /]\n[contact-field label="Correo electrónico" type="email" required="true" /]\n[contact-field label="Mensaje" type="textarea" required="true" /]\n[/contact-form]', '<form><label>Nombre<input name="name" autocomplete="name" required></label><label>Correo electrónico<input name="email" type="email" autocomplete="email" required></label><label>Mensaje<textarea name="message" required></textarea></label><p class="form-note">Maqueta: este formulario no envía ni almacena mensajes. El formulario real debe configurarse en WordPress.com.</p><button type="submit">Probar formulario de maqueta</button><p role="status" id="form-status"></p></form>')
    body=re.sub(r'\[googlemaps [^\]]+\]', '<div class="map"><span aria-hidden="true">⌖</span><h3>Santiago, Chile</h3><p>Ubicación referencial · sin local comercial</p><a href="'+E(CONFIG['map_url'])+'" target="_blank" rel="noopener">Ver ubicación en OpenStreetMap ↗</a><p>El mapa interactivo se configura en WordPress.com.</p></div>',body)
    body=body.replace(h('Últimos artículos').split('\n',1)[1].rsplit('\n',2)[0],'<h2>Últimos artículos</h2><a class="news-card" href="articulo.html"><img src="../assets/estacion.png" alt="Estación de carga conceptual"><div><span>ARTÍCULOS · 16 OCT 2026</span><h3>'+E(ARTICLE['title'])+'</h3><p>'+E(ARTICLE['excerpt'])+'</p><b>Leer el artículo ↗</b></div></a>')
    for key,fn in [('sesiones','lineas.svg'),('costos','barras.svg')]:
        body=re.sub(r'<p>\[VISUALIZACIÓN FLOURISH PENDIENTE: '+('gráfico de líneas' if key=='sesiones' else 'gráfico de barras horizontales')+r'.*?</p>','<figure class="chart"><img src="../datos/'+fn+'" alt="Boceto '+('de sesiones mensuales de enero a junio' if key=='sesiones' else 'de comparación de cuatro costos mensuales')+'"><figcaption>Boceto local de referencia. Pendiente crear e insertar la visualización real en Flourish.</figcaption></figure>',body)
    mapping={'/':'index.html','/empresa/':'empresa.html','/soluciones/':'soluciones.html','/contacto/':'contacto.html','/category/articulos/':'articulos.html','/'+SLUG+'/':'articulo.html'}
    for src,dst in mapping.items():body=body.replace('href="'+E(link(src))+'"','href="'+dst+'"')
    return body

def document(title,body,key):
    links=[('Inicio','index.html'),('Empresa','empresa.html'),('Soluciones','soluciones.html'),('Artículos','articulos.html'),('Contacto','contacto.html')]
    nav=''.join('<a '+('aria-current="page" ' if f==key else '')+'href="'+f+'">'+s+'</a>' for s,f in links)
    return '<!doctype html><html lang="es-CL"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>'+E(title)+' | Green Charge</title><link rel="stylesheet" href="style.css"></head><body><a class="skip" href="#contenido">Saltar al contenido</a><div class="topbar">PROYECTO ACADÉMICO FICTICIO · BUSINESS TECH 2026</div><header><a class="brand" href="index.html"><span aria-hidden="true">↯</span> Green Charge<span class="brand-dot">.</span></a><nav aria-label="Principal">'+nav+'</nav></header><main id="contenido">'+body+'</main><footer><div><a class="brand" href="index.html">↯ Green Charge.</a><p>Energía para tu próximo trayecto.</p></div><nav aria-label="Pie de página">'+nav+'</nav><p class="legal">'+E(DATA['project']['academic_notice'])+'</p><p class="legal">Maqueta local. No es un sitio publicado en WordPress.com. Imágenes conceptuales generadas con IA.</p></footer><script src="app.js"></script></body></html>'

for id,title,slug,body in PAGES+[POST]:
    fn='index.html' if slug=='inicio' else 'articulo.html' if id==201 else slug+'.html'
    rendered=preview_body(body)
    if id==201: rendered='<p class="eyebrow">ARTÍCULOS · 16 OCTUBRE 2026</p><h1>'+E(title)+'</h1>'+rendered
    else: rendered=re.sub(r'<h2([^>]*)>(.*?)</h2>',r'<h1\1>\2</h1>',rendered,count=1)
    (ROOT/'preview'/fn).write_text(document(title,rendered,fn))
archive='<p class="eyebrow">EL BLOG DE GREEN CHARGE</p><h1>Artículos</h1><p>Datos, ideas y contexto para entender la movilidad eléctrica.</p><a class="news-card" href="articulo.html"><img src="../assets/estacion.png" alt="Estación conceptual de carga eléctrica"><div><span>16 OCTUBRE 2026 · PROYECTO ACADÉMICO</span><h2>'+E(ARTICLE['title'])+'</h2><p>'+E(ARTICLE['excerpt'])+'</p><b>Leer la noticia ↗</b></div></a>'
(ROOT/'preview/articulos.html').write_text(document('Artículos',archive,'articulos.html'))
print('Generados:',name,'y seis vistas de maqueta. No se ha publicado ni importado contenido.')
