# Green Charge · paquete de trabajo para WordPress.com

Empresa ficticia de soluciones de carga eléctrica. Contenido preparado para la pauta de Business Tech UDD 2026. No se ha creado ninguna cuenta, sitio ni visualización en las plataformas. No se ha contratado ni comprado nada.

## Qué está preparado

- Cuatro páginas: Inicio, Empresa, Soluciones y Contacto; la quinta vista es el archivo de categoría **Artículos**, tal como pide la pauta.
- Seis fichas de productos/servicios, con texto, imagen ilustrativa y precios simulados.
- Noticia con doce párrafos principales, encabezados, cita ficticia identificada, tres imágenes previstas y bloque de dos columnas.
- Tres imágenes originales generadas con IA, sin marcas; se reutilizan en las seis fichas y en la noticia. No son fotos de instalaciones reales.
- Dos CSV, fórmulas y recetas para crear dos visualizaciones diferentes en Flourish. Los SVG son bocetos de referencia, no gráficos hechos en Flourish.
- XML WXR con cuatro páginas y una entrada **en borrador**, categoría Artículos y bloques nativos. Los avisos de imágenes/gráficos pendientes son intencionados: hay que reemplazarlos antes de publicar.
- Maqueta local adaptable a móvil y escritorio, con seis vistas: las cinco de navegación y la noticia. No es un tema instalable ni una web de WordPress.com.

## Estado y límites comprobados

La sesión no dispone de una cuenta autenticada ni herramientas de edición de WordPress.com/Flourish. Las solicitudes a `wordpress.com` y `help.flourish.studio` devolvieron bloqueo de proxy HTTP 403. El acceso a código público oficial de Automattic/Jetpack sí permitió comprobar la implementación de los shortcodes de formulario y mapa. Eso no demuestra su disponibilidad en una cuenta concreta ni su funcionamiento en este sitio.

No se ha confirmado que WordPress.com gratuito permita insertar una visualización interactiva de Flourish. No instalar plugins de pago ni contratar un plan para resolverlo. Un enlace o una imagen del gráfico no satisfacen el requisito de visualizaciones insertadas; si el editor gratuito rechaza la inserción, ese requisito queda pendiente y se debe consultar al docente sobre una alternativa gratuita.

## Montaje gratuito en WordPress.com

1. Crear un sitio en WordPress.com con cuenta propia. Elegir el plan gratuito y un subdominio disponible `*.wordpress.com`. No seleccionar prueba de pago, dominio personalizado ni extras. El nombre `greencharge` puede estar ocupado: no se comprobó disponibilidad.
2. Elegir **Twenty Twenty-Four** si está disponible gratuitamente. Aplicar colores desde los estilos nativos del editor: oscuro `#12312A`, verde `#176B4D`, fondo `#F5F7F2`, acento `#B7E27B`. Usar Cardo para títulos e Inter para texto si el tema los ofrece; en su defecto las tipografías predeterminadas. No requiere CSS de pago.
3. Importar `wordpress/greencharge-borrador.xml` mediante el importador de WordPress. Asignar el autor al propietario del sitio. No marcar descarga de adjuntos: el XML inicial no contiene adjuntos remotos. Importar una sola vez para evitar duplicados.
4. Subir `assets/hogar.png`, `assets/estacion.png` y `assets/equipo.png` a la biblioteca. Reemplazar los avisos `[IMAGEN PENDIENTE...]` por bloques Imagen según los nombres indicados. Usar las leyendas y textos alternativos de `wordpress/*.html`. En la noticia, elegir además `estacion.png` como **imagen destacada**; la noticia ya prevé esa imagen en el cuerpo. Si el tema repite la destacada, ocultar una de las dos apariciones, conservando tres imágenes distintas en total.
5. Revisar la página Contacto. Si el shortcode aparece como texto, reemplazarlo por el bloque Formulario nativo con Nombre, Correo y Mensaje obligatorios. Configurar el destinatario del propietario del sitio. Reemplazar el shortcode de mapa por el bloque Mapa nativo si hace falta, buscando Santiago, Chile. Aclarar que es una ubicación referencial de una empresa ficticia. Enviar una prueba y comprobar su recepción.
6. Crear en Flourish los dos gráficos siguiendo `FLOURISH.md`, publicarlos y obtener sus URL públicas. En la entrada, intentar insertar las URL en un bloque Incrustar admitido por el editor. Verificar el resultado público en escritorio y móvil. No asumir que pegar un iframe o script funciona en el plan gratuito. Mantener las tablas accesibles como complemento de las visualizaciones.
7. Publicar la noticia en la categoría **Artículos**, slug `articulos`. Confirmar la URL real del archivo de categoría: el valor habitual es `/category/articulos/`, pero el sitio podría usar otra base. No crear una página estática vacía llamada Artículos.
8. Definir **Inicio** como portada estática en las opciones de lectura/portada. El bloque Últimas entradas de Inicio debe mostrar la noticia publicada. No asignar Artículos como página estática de entradas: se pide un archivo de categoría.
9. En las plantillas del tema, crear el menú de cabecera y copiar los mismos cinco enlaces al pie: **Inicio / Empresa / Soluciones / Artículos / Contacto**. Artículos debe apuntar al archivo real de la categoría. `wordpress/navegacion.html` sirve como referencia de bloques; no modifica plantillas automáticamente. Revisar que los botones usen los enlaces reales del sitio.
10. Cuando estén resueltos imágenes, formulario, mapa y visualizaciones, publicar las cuatro páginas y dejar el sitio público. Comprobar sin iniciar sesión las cinco vistas, la noticia, el mapa, las visualizaciones y todos los enlaces. Entregar en Canvas UDD la URL pública real. Este paquete no envía nada a Canvas.

## Archivos y reconstrucción opcional

Abrir `preview/index.html` en el navegador para revisar el diseño. Para probarlo con servidor local: `python -m http.server 8080 --directory /ruta/al/wordpress-kit`. El formulario de esta maqueta **no envía ni almacena** datos y el mapa es una referencia enlazada; los componentes reales se configuran en WordPress.com.

`wordpress/*.html` contiene bloques Gutenberg para pegar en el editor de código de cada página si no se usa la importación. No pegar el CSS de la maqueta en el plan gratuito: el diseño debe adaptarse con las opciones del tema.

Para regenerar el XML con URL públicas reales, completar `wordpress/config.public.json` con el sitio, las tres imágenes ya subidas y las dos URL `https://public.flourish.studio/visualisation/NUMERO/`. Este archivo solo contiene configuración pública, nunca contraseñas. Ejecutar desde este directorio:

```bash
python tools/build.py
# Solo cuando todas las URL están completas:
python tools/build.py --publish
```

El segundo comando genera un XML con estado publicado; **no inicia sesión, importa ni publica nada por sí mismo**. Con las URL de medios completas, el XML declara tres adjuntos y relaciona `estacion.png` como destacada. En ese caso se debe permitir la descarga de adjuntos al importar, y comprobar la destacada al terminar. Puede generar copias de medios ya subidos. El generador no puede demostrar que WordPress.com acepte Flourish. Verificarlo en la cuenta antes de importar ese XML. No reimportar sobre contenido ya editado sin prever duplicados. Menús, portada y estilos requieren configuración en el editor aun con URL completas.

## Fuentes y transparencia

Los datos de actividad, precios, equipo, historia y citas son ficticios. Los cálculos son elaboración propia, no estadísticas de Chile ni tarifas de mercado. Los gráficos declaran su metodología. Las imágenes son conceptuales generadas con IA. La referencia a UDD identifica el contexto de la asignatura y no implica patrocinio de la universidad.

El diseño y el paquete están preparados para revisión. La creación de cuentas, la publicación del sitio, el envío real del formulario y las dos visualizaciones reales de Flourish siguen pendientes; no corresponde presentar esta maqueta como trabajo publicado.
