# Dos visualizaciones de Flourish · preparación gratuita

Los datos están listos; las visualizaciones todavía no se han creado en una cuenta de Flourish. Usar una cuenta y plantillas gratuitas. El plan gratuito puede publicar los datos: aquí no hay información personal, secretos ni datos reales de clientes.

## 1. Gráfico de líneas · evolución de las sesiones

- Archivo: `datos/piloto-mensual.csv` (UTF-8 con BOM).
- Plantilla: gráfico de líneas gratuito; una serie, con puntos y etiquetas.
- Categorías/eje X: columna **Mes**, manteniendo Enero, Febrero, Marzo, Abril, Mayo y Junio en ese orden. Si la plantilla exige fechas, configurar estas etiquetas como categorías, no como fechas incompletas.
- Valores/eje Y: columna **Sesiones**; mínimo 0, máximo sugerido 450. No seleccionar energía ni clientes como series adicionales.
- Título: **Sesiones de carga en el piloto académico**.
- Subtítulo: **Enero–junio de 2026 · datos simulados**.
- Color de serie: `#176B4D`; fondo claro. Eje Y: **Sesiones de carga**. Mostrar valores al pasar el cursor, con etiquetas de mes en español.
- Fuente visible: **Elaboración propia para el proyecto académico ficticio Green Charge. Datos sintéticos; no corresponden a una operación real.**
- Texto alternativo/explicación: **Las sesiones simuladas crecen de 120 en enero a 390 en junio: 160, 210, 270 y 330 en los meses intermedios. Total semestral: 1.480 sesiones.**

Verificación: enero 120; junio 390; suma 1.480; cambio `(390−120)/120 = 225 %`. La energía usa 18 kWh por sesión y suma 26.640 kWh. Los clientes activos mensuales no se suman como clientes únicos.

## 2. Barras horizontales · comparación de costos

- Archivo: `datos/comparacion-costos.csv`.
- Plantilla: gráfico de barras horizontales gratuito, distinto del gráfico de líneas anterior.
- Etiquetas: columna **Escenario**; valores: **Costo mensual (CLP)**. Las demás columnas documentan el cálculo; no son series adicionales.
- Orden ascendente: Carga en casa / Carga pública AC / Carga rápida DC / Auto a bencina.
- Título: **Costo energético para recorrer 1.000 km al mes**.
- Subtítulo: **Escenarios hipotéticos · pesos chilenos (CLP)**.
- Eje numérico desde 0; etiqueta **Costo mensual simulado (CLP)**. Formato sin decimales, separador de miles en español y sufijo CLP. Usar etiquetas `$30.000`, `$45.000`, `$60.000` y `$91.000`.
- Colores de carga: `#176B4D`, `#3C8966`, `#94BC76`; bencina: `#67766E`. Mantener etiquetas para que el color no sea la única distinción.
- Fuente visible: **Cálculo propio con precios simulados. VE: 15 kWh/100 km; térmico: 7 L/100 km. Precios: 200/300/400 CLP por kWh y 1.300 CLP por litro. Excluye otros costos y pérdidas de carga.**
- Texto alternativo: **Para 1.000 km mensuales, los costos energéticos simulados son $30.000 en casa, $45.000 en carga pública AC, $60.000 en carga rápida DC y $91.000 con bencina. No son tarifas reales ni costo total de propiedad.**

Fórmula: `distancia mensual / 100 × consumo por 100 km × precio unitario`. VE: `1000/100 × 15 = 150 kWh`; bencina: `1000/100 × 7 = 70 L`. Aplicar cada precio simulado. No confundir costo del combustible con precio del vehículo ni atribuir reducciones ambientales verificadas.

## Publicación e inserción

1. Publicar cada visualización en Flourish con sus fuentes visibles. Conservar dos URL públicas diferentes, con forma `https://public.flourish.studio/visualisation/ID/`.
2. En la noticia de WordPress.com, insertar la primera después del análisis de sesiones y la segunda después de la comparación de costos. Mantener las tablas de datos.
3. Probar primero el bloque Incrustar y el método oficial que el editor admita. No se ha confirmado compatibilidad en el plan gratuito; no usar un supuesto shortcode `[flourish]` ni dar por hecho que se permiten scripts/iframes.
4. Abrir el sitio sin sesión y revisar que aparezcan ambas visualizaciones, sin barras cortadas, con textos legibles y respuesta a interacción en móvil y escritorio. Un enlace, SVG o PNG aislado no cumple la inserción solicitada.
5. Si el plan gratuito rechaza la inserción, dejar ese punto pendiente y consultar una alternativa gratuita con el docente. No pagar ni activar pruebas comerciales. Los bocetos `lineas.svg` y `barras.svg` solo sirven para revisar la intención visual.
