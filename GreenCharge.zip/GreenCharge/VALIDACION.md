# Validación del paquete Green Charge

Comprobaciones locales ejecutadas el 16 de octubre de 2026:

- Seis vistas revisadas con Chromium/Playwright a 1.440 y 390 píxeles: **12 comprobaciones aprobadas**. Cada vista tiene cinco enlaces de cabecera y cinco de pie, un título principal y ningún desbordamiento horizontal.
- Todos los enlaces locales respondieron HTTP 200; todas las imágenes y ambos bocetos SVG cargaron. El catálogo tiene seis imágenes y el artículo tres imágenes conceptuales más dos bocetos de gráficos.
- El formulario de la maqueta valida sus tres campos y muestra explícitamente que no envía mensajes. No se realizó ningún envío real.
- Los seis archivos de bloques Gutenberg se analizaron con el parser oficial `@wordpress/block-serialization-default-parser`: **178 bloques reconocidos**. Esto comprueba la sintaxis, no la aceptación de todos los bloques por una cuenta de WordPress.com.
- XML WXR leído con parser XML: cuatro páginas y una noticia, todas en borrador; noticia asignada a Artículos.
- Cálculos revisados desde CSV: 1.480 sesiones y 26.640 kWh; los cuatro costos resultan de distancia, consumo y precio unitario declarados.
- El generador rechaza producir XML con estado público cuando faltan las URL reales requeridas. La estructura de adjuntos y la relación con la imagen destacada se comprobaron en una copia temporal con URL de ejemplo, sin conexión ni publicación.

Capturas: `preview/diseno-1440.png`, `preview/diseno-390.png`, `preview/articulo-desktop.png`. Resultados del navegador: `validacion-local.json`.

## Pendiente en las plataformas

No se creó ni publicó un sitio en WordPress.com ni visualizaciones en Flourish. No hubo una cuenta autenticada ni herramientas de edición disponibles. La red bloqueó las solicitudes a sus páginas con HTTP 403. La evidencia del código oficial de Jetpack permite preparar formularios y mapas, pero no demuestra su operación en un sitio real ni el soporte de Flourish en el plan gratuito.

Por ello, siguen sin validar: importación real, estilos del tema, portada estática, menús del tema, medios y destacada en WordPress, entrega de mensajes, mapa interactivo, las dos visualizaciones reales insertadas, acceso público y entrega de la URL. La maqueta y el XML de borradores no acreditan esos puntos de la pauta.
